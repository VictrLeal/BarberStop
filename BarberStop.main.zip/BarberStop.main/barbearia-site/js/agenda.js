// This file handles the calendar functionality, allowing users to select dates, times, and services for appointments.

const barberData = [
    {
        id: 1,
        name: "Barbeiro 1",
        services: [
            { name: "Corte Masculino", price: 30, duration: 30 },
            { name: "Barba", price: 20, duration: 20 },
            { name: "Corte + Barba", price: 45, duration: 50 },
            { name: "Pigmentação", price: 50, duration: 40 },
            { name: "Sobrancelha", price: 15, duration: 15 },
            { name: "Acabamento", price: 10, duration: 10 }
        ]
    },
    {
        id: 2,
        name: "Barbeiro 2",
        services: [
            { name: "Corte Masculino", price: 35, duration: 30 },
            { name: "Barba", price: 25, duration: 20 },
            { name: "Corte + Barba", price: 50, duration: 50 },
            { name: "Pigmentação", price: 55, duration: 40 },
            { name: "Sobrancelha", price: 20, duration: 15 },
            { name: "Acabamento", price: 15, duration: 10 }
        ]
    }
];

const today = new Date();
const availableTimes = [
    "08:00", "08:30", "09:00", "09:30", "10:00", "10:30",
    "11:00", "13:00", "13:30", "14:00", "14:30", "15:00",
    "15:30", "16:00", "16:30", "17:00", "17:30"
];

function isDateValid(date) {
    const day = date.getDay();
    return date >= today && day !== 0; // No Sundays and no past dates
}

function getAvailableDates() {
    const dates = [];
    const nextDays = 30; // Look ahead for 30 days
    for (let i = 0; i <= nextDays; i++) {
        const nextDate = new Date();
        nextDate.setDate(today.getDate() + i);
        if (isDateValid(nextDate)) {
            dates.push(nextDate);
        }
    }
    return dates;
}

function displayAvailableTimes(selectedDate) {
    const day = selectedDate.getDay();
    const timesContainer = document.getElementById("available-times");
    timesContainer.innerHTML = ""; // Clear previous times
    availableTimes.forEach(time => {
        const timeOption = document.createElement("option");
        timeOption.value = time;
        timeOption.textContent = time;
        timesContainer.appendChild(timeOption);
    });
}

document.getElementById("date-picker").addEventListener("change", function() {
    const selectedDate = new Date(this.value);
    displayAvailableTimes(selectedDate);
});

document.getElementById("appointment-form").addEventListener("submit", function(event) {
    event.preventDefault();
    const name = document.getElementById("name").value;
    const phone = document.getElementById("phone").value;
    const service = document.getElementById("service").value;
    const date = document.getElementById("date-picker").value;
    const time = document.getElementById("available-times").value;

    const barberId = new URLSearchParams(window.location.search).get("id");
    const barber = barberData.find(b => b.id == barberId);

    const message = `Olá!\nGostaria de solicitar um agendamento.\nNome: ${name}\nTelefone: ${phone}\nBarbeiro: ${barber.name}\nServiço: ${service}\nData: ${date}\nHorário: ${time}\nAguardo sua confirmação.`;
    const whatsappUrl = `https://wa.me/?text=${encodeURIComponent(message)}`;
    window.open(whatsappUrl, "_blank");
});