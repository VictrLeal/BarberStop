// admin.js

const senha = "123456"; // Senha para acesso ao painel administrativo

// Função para solicitar a senha ao acessar o painel
function solicitarSenha() {
    const inputSenha = prompt("Digite a senha para acessar o painel administrativo:");
    if (inputSenha === senha) {
        abrirPainel();
    } else {
        alert("Senha incorreta. Acesso negado.");
    }
}

// Função para abrir o painel administrativo
function abrirPainel() {
    document.getElementById("painel").style.display = "block"; // Exibe o painel
    carregarAgenda(); // Carrega a agenda ao abrir o painel
}

// Função para bloquear datas
function bloquearData(data) {
    let datasBloqueadas = JSON.parse(localStorage.getItem("datasBloqueadas")) || [];
    if (!datasBloqueadas.includes(data)) {
        datasBloqueadas.push(data);
        localStorage.setItem("datasBloqueadas", JSON.stringify(datasBloqueadas));
    }
}

// Função para desbloquear datas
function desbloquearData(data) {
    let datasBloqueadas = JSON.parse(localStorage.getItem("datasBloqueadas")) || [];
    datasBloqueadas = datasBloqueadas.filter(d => d !== data);
    localStorage.setItem("datasBloqueadas", JSON.stringify(datasBloqueadas));
}

// Função para visualizar a agenda
function carregarAgenda() {
    const agenda = JSON.parse(localStorage.getItem("agenda")) || [];
    // Lógica para exibir a agenda na interface
}

// Função para adicionar feriados
function adicionarFeriado(data) {
    let feriados = JSON.parse(localStorage.getItem("feriados")) || [];
    if (!feriados.includes(data)) {
        feriados.push(data);
        localStorage.setItem("feriados", JSON.stringify(feriados));
    }
}

// Função para editar horários disponíveis
function editarHorarios(horario, status) {
    let horariosDisponiveis = JSON.parse(localStorage.getItem("horariosDisponiveis")) || [];
    if (status === "bloquear") {
        if (!horariosDisponiveis.includes(horario)) {
            horariosDisponiveis.push(horario);
        }
    } else {
        horariosDisponiveis = horariosDisponiveis.filter(h => h !== horario);
    }
    localStorage.setItem("horariosDisponiveis", JSON.stringify(horariosDisponiveis));
}

// Chama a função de solicitar senha ao carregar a página
window.onload = solicitarSenha;