// Main JavaScript logic for the barbershop website

// Object containing barber data
const barbeiros = [
    {
        id: 1,
        nome: "Barbeiro 1",
        foto: "assets/barbeiros/barbeiro1.jpg",
        descricao: "Especialista em cortes clássicos e modernos.",
        especialidades: ["Corte Masculino", "Barba", "Corte + Barba"],
        whatsapp: "1234567890",
        servicos: [
            { nome: "Corte Masculino", preco: 30, tempo: "30 min" },
            { nome: "Barba", preco: 20, tempo: "20 min" },
            { nome: "Corte + Barba", preco: 45, tempo: "50 min" }
        ]
    },
    {
        id: 2,
        nome: "Barbeiro 2",
        foto: "assets/barbeiros/barbeiro2.jpg",
        descricao: "Especialista em estilos modernos e cuidados com a barba.",
        especialidades: ["Corte Masculino", "Pigmentação", "Sobrancelha"],
        whatsapp: "0987654321",
        servicos: [
            { nome: "Pigmentação", preco: 50, tempo: "40 min" },
            { nome: "Sobrancelha", preco: 15, tempo: "15 min" },
            { nome: "Acabamento", preco: 25, tempo: "20 min" }
        ]
    }
];

// Function to initialize the homepage
function initHomePage() {
    const agendarButton = document.getElementById("agendar-button");
    agendarButton.addEventListener("click", () => {
        // Logic to navigate to the scheduling section
        scrollToSection("scheduling");
    });

    // Load barber cards
    loadBarberCards();
}

// Function to load barber cards dynamically
function loadBarberCards() {
    const barberContainer = document.getElementById("barber-container");
    barbeiros.forEach(barbeiro => {
        const card = document.createElement("div");
        card.className = "barber-card";
        card.innerHTML = `
            <img src="${barbeiro.foto}" alt="${barbeiro.nome}" />
            <h3>${barbeiro.nome}</h3>
            <p>${barbeiro.descricao}</p>
            <button onclick="navigateToBarber(${barbeiro.id})">Agendar</button>
        `;
        barberContainer.appendChild(card);
    });
}

// Function to navigate to the barber page
function navigateToBarber(id) {
    window.location.href = `barbeiro.html?id=${id}`;
}

// Smooth scroll function
function scrollToSection(sectionId) {
    const section = document.getElementById(sectionId);
    section.scrollIntoView({ behavior: "smooth" });
}

// Initialize the homepage when the window loads
window.onload = initHomePage;