# Barbearia Site

Este projeto é um site estático para uma barbearia moderna, desenvolvido utilizando HTML5, CSS3 e JavaScript puro. O objetivo é proporcionar uma experiência premium aos usuários, permitindo agendamentos de serviços de forma simples e eficiente.

## Estrutura do Projeto

- **index.html**: Página inicial com seção hero, logo, título e botões para agendamento.
- **barbeiro.html**: Página que exibe informações sobre um barbeiro específico, incluindo especialidades e formulário de agendamento.
- **admin.html**: Painel administrativo protegido por senha, permitindo a gestão de agendamentos e horários.
- **css/**: Contém os arquivos de estilo para o site.
  - **style.css**: Estilos principais do site.
  - **home.css**: Estilos específicos para a página inicial.
  - **barbeiro.css**: Estilos para a página de detalhes do barbeiro.
  - **admin.css**: Estilos para o painel administrativo.
- **js/**: Contém os arquivos JavaScript que gerenciam a lógica do site.
  - **main.js**: Lógica principal do site.
  - **agenda.js**: Funcionalidade do calendário para agendamentos.
  - **admin.js**: Funcionalidades administrativas.
  - **whatsapp.js**: Geração de mensagens para confirmação de agendamentos via WhatsApp.
- **assets/**: Contém imagens e ícones utilizados no site.
  - **logo.png**: Logo da barbearia.
  - **favicon.ico**: Ícone do site.
  - **background/hero.jpg**: Imagem de fundo da seção hero.
  - **barbeiros/**: Imagens dos barbeiros.
  - **clientes/**: Imagens de cortes de cabelo.

## Funcionalidades

- Agendamento de serviços com seleção de data, horário e barbeiro.
- Painel administrativo para gestão de agendamentos e horários.
- Integração com WhatsApp para confirmação de agendamentos.
- Design responsivo e otimizado para diferentes dispositivos.

## Como Usar

1. Clone o repositório ou faça o download dos arquivos.
2. Abra o arquivo `index.html` em um navegador para visualizar o site.
3. Utilize o painel administrativo acessando `admin.html` e insira a senha para gerenciar os agendamentos.

## Tecnologias Utilizadas

- HTML5
- CSS3
- JavaScript (Vanilla JS)

## Contribuições

Contribuições são bem-vindas! Sinta-se à vontade para abrir issues ou pull requests.

## Licença

Este projeto é de uso livre.