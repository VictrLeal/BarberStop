// This file generates the WhatsApp message for appointment confirmations based on user input.

function generateWhatsAppMessage(name, phone, barber, service, date, time) {
    const message = `Olá!\n\nGostaria de solicitar um agendamento.\n\nNome:\n${name}\n\nTelefone:\n${phone}\n\nBarbeiro:\n${barber}\n\nServiço:\n${service}\n\nData:\n${date}\n\nHorário:\n${time}\n\nAguardo sua confirmação.`;
    return encodeURIComponent(message);
}

function openWhatsApp(name, phone, barber, service, date, time) {
    const message = generateWhatsAppMessage(name, phone, barber, service, date, time);
    const whatsappUrl = `https://wa.me/?text=${message}`;
    window.open(whatsappUrl, '_blank');
}